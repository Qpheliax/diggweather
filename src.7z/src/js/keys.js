module.exports = {
    googleKey: "AIzaSyAjYZeEX50fZhx7HRSIFH_XdFzcLPkEa2w",
    googleBase: "https://maps.googleapis.com/maps/api/geocode/json?latlng=",
    smhiBase: "https://opendata-download-metfcst.smhi.se/api/category/pmp3g/version/2/geotype/point/",
  };