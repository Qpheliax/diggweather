import React from "react";
import Forecast from "../functions/location";

const Weather = () => {
  return (
    <main>
      <Forecast />
    </main>
  );
};

export default Weather;
