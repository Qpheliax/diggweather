import React from "react";


const City = (location) => {

  return (
    <div>
      {location ? (
           {data.city}
      ) : (
        <p>Loading...</p>
      )}
      {error && <p className="errorMessage">Location Error: {error}</p>}
    </div>
  );
};


export default City;