import React from "react";
import Forecast from "./location";

const Weather = () => {

  return (
    <main>
     <Forecast />
    </main>
  );
};

export default Weather;
