export const url = "https://api.opencagedata.com/geocode/v1/json?q=";
export const smhiUrl =
  "https://opendata-download-metfcst.smhi.se/api/category/pmp3g/version/2/geotype/point/";
export const key = "527961ee26f54468a0a374c839e9565d";