import React from 'react';

const Footer = () => (
        <footer>
        <h3>2021</h3>
      </footer>
    );

export default Footer;